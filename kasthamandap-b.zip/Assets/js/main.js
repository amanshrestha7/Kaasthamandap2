$(document).ready(function(){
	$(document).on("click",".navbar-toggle",function(){
		$(".navbar").find(".navbar-collapse").slideToggle();
	});
	$(window).scroll(function(){
		if ($(this).scrollTop() > 200) {
			$('.scrollToTop').fadeIn();
		} else {
			$('.scrollToTop').fadeOut();
		}
	});


	//Chevron-down slide animation
        $(".about-arrow-down a").click(function(e) {
            e.preventDefault();

            var target = $(this).attr("href");
            $('html, body').animate({
                scrollTop: $(target).offset().top,
            }, 500);
            return false;

        });



	// slick for banner section mobile only
	var slickWrap=$('.slick-slider-wrap');
	function bannerSlick(){
		var wWidth=$(window).width();
		if(wWidth < 992 ){
			slickWrap.not('.slick-initialized').slick({
				slidesToShow: 5,
				centerMode: false,
				arrows: false,
				autoplay: true,
				autoplaySpeed: 2000,
				responsive: [
					{
				      breakpoint: 991,
				      settings: {
				        arrows: false,
				        centerMode: false,
				       
				        slidesToShow: 3
				      }
				    },
				    {
				      breakpoint: 768,
				      settings: {
				        arrows: false,
				        centerMode: false,
				       
				        slidesToShow: 2
				      }
				    },
				    {
				      breakpoint: 480,
				      settings: {
				        arrows: false,
				        centerMode: false,
				    
				        slidesToShow: 1
				      }
				    }
			  ]
			});
		}
	}

	bannerSlick();
	$(window).on("resize",function(){
		bannerSlick();
	})


	// slick for testimonials section
	$('.testimonials-slick').slick({
		dots: true,
		infinite: true,
		fade: true,
		autoplay: true,
		autoplaySpeed: 2000,
		cssEase: 'linear'
	});


	// slick for news and event section
	$('.events-section').slick({
		slidesToShow: 3,
		centerMode: false,
		arrows: false,
		autoplay: true,
		autoplaySpeed: 2000,
		responsive: [
			{
		      breakpoint: 991,
		      settings: {
		        arrows: false,
		        centerMode: false,
		    
		        slidesToShow: 3
		      }
		    },
		    {
		      breakpoint: 767,
		      settings: {
		        arrows: false,
		        centerMode: false,
		    
		        slidesToShow: 2
		      }
		    },
		    {
		      breakpoint: 480,
		      settings: {
		        arrows: false,
		        centerMode: false,
		       
		        slidesToShow: 1
		      }
		    }
	  ]
	});


	//Match Height For News and Event Section
	$(function() {
		$('.news-section').matchHeight(
		{
		    byRow: true,
		    property: 'height',
		    target: null,
		    remove: false
		});
	});

	//Match Height For School schedule Section
	$(function() {
		$('.programs').matchHeight(
		{
		    byRow: true,
		    property: 'height',
		    target: null,
		    remove: false
		});
	});


	//Match Height For Banner Section
	$(function() {
		$('.slick-slider-wrap .caption').matchHeight(
		{
		    byRow: true,
		    property: 'height',
		    target: null,
		    remove: false
		});
	});


	//Match Height For Banner Section title
	$(function() {
		$('.slick-slider-wrap .caption .title').matchHeight(
		{
		    byRow: true,
		    property: 'height',
		    target: null,
		    remove: false
		});
	});

	//Match Height For Academic Section
	$(function() {
		$('.mission .mission-class').matchHeight(
		{
		    byRow: true,
		    property: 'height',
		    target: null,
		    remove: false
		});
	});


	//Match Height For Academic Section
	$(function() {
		$('.mission-class .rr14').matchHeight(
		{
		    byRow: false,
		    property: 'height',
		    target: null,
		    remove: false
		});
	});



	//Match Height For Academic Section
	$(function() {
		$('.notice-box p').matchHeight(
		{
		    byRow: true,
		    property: 'height',
		    target: null,
		    remove: false
		});
	});



	// //match Height For News Section
	// $(function() {
	// 	$('.news-main-block').matchHeight(
	// 	{
	// 	    byRow: false,
	// 	    property: 'height',
	// 	    target: null,
	// 	    remove: false
	// 	});
	// });

	//Full Screen Image on Click... Gallery Section
	lightbox.option({
      'resizeDuration': 200,
      'wrapAround': true
    })



    // For Maps
	function myMap() {
	var mapProp= {
	    center:new google.maps.LatLng(51.508742,-0.120850),
	    zoom:5,
	};
	var map=new google.maps.Map(document.getElementById("googleMap"),mapProp);
	}
	//End of Map Section


	//Form Validation
	$(".form-validation").validate({
	rules: {
		fullname: {
			required: true,
			minlength: 6
		},

		emailaddress: {
			minlength: 6,
			required: true,
			email: true
		},

		subject: {
			minlength: 6,
			required: true
		},
		
		message: {
			minlength: 30,
			required: true
		}
	},


	messages: {
		fullname: {
			required:  "Enter Your Full Name",
			minlength: "Must contain at least 6 characters"
		},


		emailaddress: {
			required: "Enter Your Email Address",
			minlength: "Must contain at least 6 characters",
			email: "Enter Valid Email"
		},

		subject: {
			required: "Subject is must",
			minlength: "Must contain 6 letters",
		},

		message: {
			minlength: "Must contain at least 30 characters",
			required: "What's your message?"
		}
	}
	});
});